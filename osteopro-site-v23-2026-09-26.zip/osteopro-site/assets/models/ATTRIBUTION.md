# Adapted anatomy model

3D anatomy: Z-Anatomy (CC BY-SA 4.0) and BodyParts3D, © 2008 Database Center for Life Science (CC BY-SA 2.1 JP). Adapted.

The included `spine.glb` itself is shared under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Retain this attribution and the same licence when sharing an adaptation of this model.

- Immediate source: [FitMitWith anatomy atlas, slfresh](https://github.com/slfresh/fitmitwith-anatomy-atlas), `models/full-body-male-mobile.glb`, master branch, retrieved 25 September 2026.
- Upstream: [Z-Anatomy models](https://github.com/Z-Anatomy/Models-of-human-anatomy), CC BY-SA 4.0; contributors include Gauthier Kervyn and Marcin Zielinski.
- Original anatomical source: [BodyParts3D, Database Center for Life Science](https://lifesciencedb.jp/bp3d/), © 2008, Kousaku Okubo; [CC BY-SA 2.1 Japan](https://creativecommons.org/licenses/by-sa/2.1/jp/). The current BodyParts3D site also provides attribution under CC BY 4.0; this distribution retains the upstream notices and the brief's required attribution.
- Adaptation for OsteoPro: extracted the vertebral column from C1 to the sacrum and bilateral iliocostalis lumborum, longissimus thoracis and spinalis thoracis. Selected 25 skeletal components and six muscle meshes. Removed unrelated geometry, calculated normals, quantised and Meshopt-compressed the mesh. Runtime materials, centring, rotation and scan are presentation adaptations. No separately licensed organ models are included.
- The static poster is rendered from this adapted model and carries the same attribution and CC BY-SA 4.0 licence.

This is illustrative anatomy, not a patient recording. The source's anatomical proportions and segmentation have not been independently reviewed by an anatomy specialist.
