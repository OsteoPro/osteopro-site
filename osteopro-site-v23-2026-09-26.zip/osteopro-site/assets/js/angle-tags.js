/* Counts the hero angle readouts up, top to bottom, when the hero comes into view. Remove this file's <script> tag to revert. */
(()=>{const box=document.querySelector('.angle-tags');if(!box||matchMedia('(prefers-reduced-motion:reduce)').matches)return;
const tags=[...box.querySelectorAll('.tag')].map(el=>{const n=[...el.childNodes].find(x=>x.nodeType===3&&/\d/.test(x.textContent));if(!n)return null;const m=n.textContent.match(/(−|-)?(\d+)°/);return{el,n,neg:!!m[1],v:+m[2]}}).filter(Boolean);
box.classList.add('animated');const fmt=(g,v)=>(g.neg&&v>0?'−':'')+v+'°';
let running=false;
function run(){if(running)return;running=true;const t0=performance.now();tags.forEach(g=>{g.n.textContent=fmt(g,0);g.el.classList.remove('done','hit')});
 function f(now){let busy=false;tags.forEach((g,i)=>{const dt=now-t0-400-i*900;if(dt<0){busy=true;return}const k=Math.min(dt/900,1),v=Math.round(g.v*(1-Math.pow(1-k,3)));g.n.textContent=fmt(g,v);g.el.classList.add('done');g.el.classList.toggle('hit',dt<1200);if(dt<1200)busy=true});busy?requestAnimationFrame(f):(running=false)}
 requestAnimationFrame(f)}
new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&run()),{threshold:.4}).observe(box)})();
