(() => {
 const menu=document.querySelector('.menu-toggle'),nav=document.querySelector('.main-nav');
 if(menu&&nav){const close=()=>{nav.classList.remove('is-open');menu.setAttribute('aria-expanded','false')};menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.classList.toggle('is-open',open)});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('is-open')){close();menu.focus()}});document.addEventListener('click',e=>{if(!e.target.closest('.site-header'))close()});matchMedia('(min-width:761px)').addEventListener('change',close)}
 document.querySelectorAll('[data-gallery]').forEach(g=>{const img=g.querySelector('.gallery-main img'),caption=g.querySelector('.gallery-main figcaption');g.querySelectorAll('[data-screen]').forEach(b=>b.addEventListener('click',()=>{img.src='../assets/images/'+b.dataset.screen;img.alt='Genuine Idiag M360 software: '+b.dataset.caption;caption.textContent=b.dataset.caption;g.querySelectorAll('[data-screen]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)))}))});
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),connection=navigator.connection,constrained=connection?.saveData||/(^|-)2g$|^3g$/.test(connection?.effectiveType||''),stage=document.querySelector('[data-hero]'),eligible=!reduced.matches&&!constrained;
 if(stage){
  const control=stage.querySelector('.motion-toggle');let paused=constrained;
  stage.classList.toggle('motion-paused',paused);
  if(control){control.hidden=reduced.matches;control.setAttribute('aria-pressed',String(paused));control.textContent=paused?'Resume motion':'Pause motion';control.addEventListener('click',()=>{paused=!paused;stage.classList.toggle('motion-paused',paused);control.setAttribute('aria-pressed',String(paused));control.textContent=paused?'Resume motion':'Pause motion';stage.dispatchEvent(new CustomEvent('osteopro-motion',{detail:{paused}}))});reduced.addEventListener('change',()=>control.hidden=reduced.matches)}
 }
 if(stage&&eligible){
  const load=()=>import(new URL('hero.js',document.querySelector('script[src$="site.js"]').src).href).then(m=>m.startHero(stage)).catch(()=>stage.dataset.motion='poster');
  const ready=()=>Promise.all(Array.from(stage.querySelectorAll('img')).map(img=>img.decode().catch(()=>{}))).then(()=>requestAnimationFrame(()=>requestAnimationFrame(()=>{if('requestIdleCallback'in window)requestIdleCallback(load,{timeout:2500});else setTimeout(load,500)})));
  if(matchMedia('(max-width:760px)').matches){
   stage.classList.add('poster-motion');
   const enable=document.createElement('button');enable.type='button';enable.className='motion-toggle anatomy-enable';enable.textContent='Rotate anatomy';
   enable.addEventListener('click',()=>{enable.disabled=true;enable.textContent='Loading anatomy…';ready();const watch=new MutationObserver(()=>{if(stage.dataset.motion==='ready'){enable.remove();watch.disconnect()}else if(stage.dataset.motion==='poster'){enable.textContent='Anatomy view';watch.disconnect()}});watch.observe(stage,{attributes:true,attributeFilter:['data-motion']})},{once:true});stage.append(enable);
  }else if(document.readyState==='complete')ready();else window.addEventListener('load',ready,{once:true});
 }
 if(eligible&&'IntersectionObserver'in window){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.animate([{transform:'translateY(14px)'},{transform:'translateY(0)'}],{duration:650,easing:'cubic-bezier(.2,.6,.2,1)'});io.unobserve(e.target)}}),{threshold:.08});document.querySelectorAll('[data-reveal]').forEach(e=>io.observe(e))}
})();
