// Reader for the included, position-only Meshopt anatomy asset.
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.min.js';
import {MeshoptDecoder} from 'https://cdn.jsdelivr.net/npm/three@0.170.0/examples/jsm/libs/meshopt_decoder.module.js';
export async function loadAnatomy(url){
 const response=await fetch(url);if(!response.ok)throw new Error('Model unavailable');
 const data=await response.arrayBuffer(),head=new DataView(data),jsonLength=head.getUint32(12,true);
 if(head.getUint32(0,true)!==0x46546c67||head.getUint32(4,true)!==2)throw new Error('Model format');
 const gltf=JSON.parse(new TextDecoder().decode(new Uint8Array(data,20,jsonLength))),binary=new Uint8Array(data,28+jsonLength),decoded=new Map();await MeshoptDecoder.ready;
 function view(index){if(decoded.has(index))return decoded.get(index);const descriptor=gltf.bufferViews[index],c=descriptor.extensions?.EXT_meshopt_compression;let bytes;
  if(c){bytes=new Uint8Array(c.count*c.byteStride);MeshoptDecoder.decodeGltfBuffer(bytes,c.count,c.byteStride,binary.subarray(c.byteOffset||0,(c.byteOffset||0)+c.byteLength),c.mode,c.filter)}else bytes=binary.subarray(descriptor.byteOffset||0,(descriptor.byteOffset||0)+descriptor.byteLength);
  const result=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);decoded.set(index,result);return result;
 }
 function accessor(index){const a=gltf.accessors[index],v=view(a.bufferView),components={SCALAR:1,VEC2:2,VEC3:3,VEC4:4}[a.type],methods={5120:['getInt8',1,127],5121:['getUint8',1,255],5122:['getInt16',2,32767],5123:['getUint16',2,65535],5125:['getUint32',4,4294967295],5126:['getFloat32',4,1]},[method,size,denominator]=methods[a.componentType],stride=gltf.bufferViews[a.bufferView].byteStride||size*components,result=new Float32Array(a.count*components);
  for(let i=0;i<a.count;i++)for(let c=0;c<components;c++){let value=v[method]((a.byteOffset||0)+i*stride+c*size,true);if(a.normalized)value=Math.max(-1,value/denominator);result[i*components+c]=value}return result;
 }
 const result={bones:[],muscles:[]};
 for(const node of gltf.nodes){if(node.mesh===undefined)continue;for(const primitive of gltf.meshes[node.mesh].primitives){const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(accessor(primitive.attributes.POSITION),3));geometry.setIndex(new THREE.BufferAttribute(new Uint32Array(accessor(primitive.indices)),1));
  const matrix=new THREE.Matrix4();if(node.matrix)matrix.fromArray(node.matrix);else matrix.compose(new THREE.Vector3().fromArray(node.translation||[0,0,0]),new THREE.Quaternion().fromArray(node.rotation||[0,0,0,1]),new THREE.Vector3().fromArray(node.scale||[1,1,1]));geometry.applyMatrix4(matrix);(node.extras?.region==='muscle'?result.muscles:result.bones).push(geometry);
 }}return result;
}
export function mergeGeometry(parts){const arrays=parts.map(g=>g.toNonIndexed().attributes.position.array),values=new Float32Array(arrays.reduce((sum,a)=>sum+a.length,0));let offset=0;for(const a of arrays){values.set(a,offset);offset+=a.length}const result=new THREE.BufferGeometry();result.setAttribute('position',new THREE.BufferAttribute(values,3));return result}
