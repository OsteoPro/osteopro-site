// Keep anatomy rendering off the page's interaction thread.
export function startHero(stage) {
  const holder=stage.querySelector('.anatomy-canvas'),host=stage.querySelector('.hero-anatomy');
  const reduced=matchMedia('(prefers-reduced-motion:reduce)'),toggle=stage.querySelector('.motion-toggle');
  if(!holder||!host||reduced.matches||!('OffscreenCanvas' in window)||!HTMLCanvasElement.prototype.transferControlToOffscreen){stage.dataset.motion='poster';return;}
  const canvas=document.createElement('canvas');canvas.setAttribute('aria-hidden','true');holder.append(canvas);
  let worker,paused=stage.classList.contains('motion-paused'),visible=true,ready=false,failed=false;
  const fallback=()=>{failed=true;stage.classList.remove('has-webgl');stage.dataset.motion='poster';worker?.terminate();canvas.remove()};
  try{worker=new Worker(new URL('hero-worker.js',import.meta.url),{type:'module'});}catch{fallback();return}
  const send=message=>{if(!failed)worker.postMessage(message)};
  const active=()=>send({type:'active',value:!paused&&visible&&!document.hidden&&!reduced.matches});
  const resize=()=>send({type:'resize',width:host.clientWidth,height:host.clientHeight});
  worker.onerror=fallback;
  worker.onmessage=({data})=>{if(data.type==='ready'){ready=true;stage.classList.add('has-webgl');stage.dataset.motion='ready';active()}else if(data.type==='frames')stage.dataset.frames=String(data.value);else if(data.type==='error')fallback()};
  const css=getComputedStyle(document.documentElement),colours={};['--blue-wire','--blue-wire-dim','--scan'].forEach(n=>colours[n]=css.getPropertyValue(n).trim());
  const offscreen=canvas.transferControlToOffscreen();worker.postMessage({type:'init',canvas:offscreen,width:host.clientWidth,height:host.clientHeight,dpr:Math.min(devicePixelRatio,1.25),colours},[offscreen]);
  const ro=new ResizeObserver(resize);ro.observe(host);
  const io=new IntersectionObserver(es=>{visible=es[0].isIntersecting;active()});io.observe(stage);
  stage.addEventListener('osteopro-motion',event=>{paused=event.detail.paused;active()});
  document.addEventListener('visibilitychange',active);
  reduced.addEventListener('change',()=>{stage.classList.toggle('has-webgl',ready&&!reduced.matches);active()});
  window.addEventListener('pagehide',event=>{if(!event.persisted){worker.terminate();io.disconnect();ro.disconnect()}});
}
