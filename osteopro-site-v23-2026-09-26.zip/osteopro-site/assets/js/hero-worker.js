import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.min.js';
import {loadAnatomy,mergeGeometry} from './anatomy-model.js';
let renderer,camera,scene,rig,scan,active=true,ready=false,timer=0,elapsed=0,last=0,frames=0,width=1,height=1;
const resize=()=>{if(renderer){renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();if(ready)renderer.render(scene,camera)}};
const stop=()=>{clearTimeout(timer);timer=0;last=0};
const draw=()=>{timer=0;if(!active||!ready)return;const now=performance.now();if(last)elapsed+=Math.min((now-last)/1000,.1);last=now;rig.rotation.y=-.5+Math.sin(elapsed*.22)*.26;scan.value=2.2-((elapsed*.4)%4.6);renderer.render(scene,camera);if(++frames%12===0)self.postMessage({type:'frames',value:frames});timer=setTimeout(draw,1000/24)};
async function init(data){
 const colour=name=>new THREE.Color(data.colours[name]);
 data.canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();stop();self.postMessage({type:'error'})});
 scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(27,width/height,.1,40);camera.position.z=9.8;
 renderer=new THREE.WebGLRenderer({canvas:data.canvas,alpha:true,antialias:true,powerPreference:'low-power'});renderer.setPixelRatio(data.dpr);renderer.setClearColor(0,0);renderer.outputColorSpace=THREE.SRGBColorSpace;
 rig=new THREE.Group();scene.add(rig);resize();
 const {bones,muscles}=await loadAnatomy(new URL('../models/spine.glb',import.meta.url).href);
 const anatomy=new THREE.Group();scan={value:2.4};
 const surface=new THREE.Mesh(mergeGeometry(bones),new THREE.MeshBasicMaterial({color:colour('--blue-wire'),transparent:true,opacity:.09,depthWrite:false,side:THREE.DoubleSide}));anatomy.add(surface);
 if(muscles.length)anatomy.add(new THREE.Mesh(mergeGeometry(muscles),new THREE.MeshBasicMaterial({color:colour('--blue-wire-dim'),transparent:true,opacity:.065,depthWrite:false,side:THREE.DoubleSide})));
 const material=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{uScan:scan,uColour:{value:colour('--blue-wire')},uHighlight:{value:colour('--scan')}},vertexShader:'varying float vHeight; void main(){vec4 world=modelMatrix*vec4(position,1.0);vHeight=world.y;gl_Position=projectionMatrix*viewMatrix*world;}',fragmentShader:'uniform float uScan; uniform vec3 uColour; uniform vec3 uHighlight; varying float vHeight; void main(){float beam=exp(-pow((vHeight-uScan)*8.0,2.0));gl_FragColor=vec4(mix(uColour,uHighlight,beam),0.34+beam*0.55);}'});
 surface.add(new THREE.LineSegments(new THREE.WireframeGeometry(surface.geometry),material));
 const box=new THREE.Box3().setFromObject(anatomy),size=box.getSize(new THREE.Vector3()),centre=box.getCenter(new THREE.Vector3()),frame=new THREE.Group();frame.add(anatomy);anatomy.position.sub(centre);frame.scale.setScalar(4.25/size.y);rig.add(frame);rig.rotation.set(.03,-.52,.04);
 await renderer.compileAsync(scene,camera);renderer.render(scene,camera);ready=true;self.postMessage({type:'ready'});draw();
}
self.onmessage=({data})=>{if(data.type==='init'){width=data.width;height=data.height;init(data).catch(()=>self.postMessage({type:'error'}))}else if(data.type==='resize'){width=data.width;height=data.height;resize()}else if(data.type==='active'){active=data.value;active?(!timer&&draw()):stop()}};
