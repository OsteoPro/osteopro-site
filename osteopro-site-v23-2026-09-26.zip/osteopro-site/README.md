# OsteoPro website v2

Four static HTML pages revised from `osteopro-site-current.zip` against the v2 brief. All contact links use admin@osteopro.com.au. Extract this ZIP with `index.html` at the site root. Cloudflare Pages needs no build command; upload the extracted directory. No deployment was performed.

For a local preview, serve this directory over HTTP, for example `python3 -m http.server 8000`, and visit `http://localhost:8000`. Opening the HTML directly remains readable; the animated anatomy requires HTTP(S) and access to jsDelivr.

## File map

| Path | Contents |
| --- | --- |
| `index.html` | Home, balanced two-device hero, clearance cards, genuine software, owner photographs and online support |
| `idiag-m360/index.html` | Original device copy, seven genuine software views, case render and support |
| `mobee-med/index.html` | Original device copy, genuine ankle software screen, case render and support |
| `evidence/index.html` | Three original study paragraphs with their existing limitations |
| `assets/css/tokens.css` | All interface colours and shared design tokens |
| `assets/css/site.css` | Responsive layouts, keyboard focus and reduced-motion rules |
| `assets/js/site.js` | Navigation, software gallery, motion control and progressive enhancement |
| `assets/js/hero.js` | Offscreen anatomy lifecycle, viewport and visibility handling |
| `assets/js/hero-worker.js` | Three.js anatomy rendering away from the interaction thread |
| `assets/js/anatomy-model.js` | Reader for the included Meshopt-compressed GLB |
| `assets/brand/logo-transparent.png` | The supplied logo, byte-for-byte unchanged |
| `assets/models/spine.glb` | Adapted C1–sacrum anatomy plus six back-muscle meshes; 152,592 bytes |
| `assets/models/ATTRIBUTION.md` | Model provenance, adaptations and licence |
| `assets/images/` | Four generated device/case renders; eight genuine software screens; four owner photographs; anatomy poster and responsive image derivatives |
| `robots.txt`, `sitemap.xml` | Crawl instructions and four canonical URLs |
| `reference-list.md` | Retained Step 1 references and the patterns applied |
| `scorecard.md` | Final Step 2 assessment and validation evidence |
| `file-list.txt` | Complete inventory of the delivered files |
| `README.md` | Operation, provenance and remaining verification limits |

## Assets and design

The supplied transparent logo is the only logo asset. A separate HTML OsteoPro wordmark accompanies it. The accent is the supplied mark's blue, RGB 28, 73, 153. All interface colour literals are in `tokens.css`; the anatomy worker receives these colour tokens from the page.

Both devices have a high-resolution transparent WebP render and an open-case render, with smaller responsive derivatives. Generated renders contain no logos. Each displayed render carries its illustrative label and the exact disclaimer. The mobee shape is based on the supplied flyer reference; the flyer itself is not included. Case interiors are illustrative because a stock-case photograph was not supplied.

Software imagery uses the owner's actual screens. Idiag screenshots are cropped to the working pane where appropriate; the expert report retains its complete original screen. These crops do not change the values or graphs. The mobee ankle result is the genuine supplied screen. High-resolution versions remain on the product pages.

The event photographs use genuine pixels and truthful crops. The live-stage crop excludes the participant's face and the projection. The second event photograph shows Andrew holding the spinal device. CSS exposure and colour adjustments improve readability without inventing facial or stage details. Original low-light and low-resolution limitations remain. The remote-session crop preserves the existing face/name masks. The headshot is displayed small. The alternative stage frames were omitted where duplicate content, another visible face or projected artwork would weaken the crop. The optional team collage is omitted.

## Motion and fallback

Three.js 0.170.0 and its Meshopt decoder load from version-pinned jsDelivr URLs. The GLB is loaded after visible hero images decode. Rendering runs in an OffscreenCanvas worker, with a 24-frame-per-second ceiling and capped pixel density. The geometry is combined into a small number of draw calls. On desktop the spine slowly rotates and carries a descending scan; the other product has an animated joint-angle arc. On mobile a lightweight animated scan plays over the anatomy poster alongside the joint arc; “Rotate anatomy” starts the real 3D view on demand. This avoids loading a graphics engine before the visitor asks for it.

Pause/resume controls both animations. Rendering pauses off screen and while the document is hidden. Reduced motion disables animation. Data-saving and slower connections keep the poster; unavailable workers, WebGL or CDN resources also preserve the poster and all page content. Browsers without OffscreenCanvas use the poster. No JavaScript is required to read or navigate the pages; the mobile menu remains expanded in that case.

## Anatomy attribution

3D anatomy: Z-Anatomy (CC BY-SA 4.0) and BodyParts3D, © 2008 Database Center for Life Science (CC BY-SA 2.1 JP). Adapted.

Licences: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) and [CC BY-SA 2.1 Japan](https://creativecommons.org/licenses/by-sa/2.1/jp/). The model itself and its poster are shared under CC BY-SA 4.0. See `assets/models/ATTRIBUTION.md` for sources and modifications. This licence applies to the model and poster, not to the owner's photographs or logo.

## Validation and limits

See `scorecard.md` for the final combined check and improvement pass. Browser checks use Chromium with desktop and mobile viewport emulation. The test environment serves identical pinned CDN files locally and uses HTTP compression corresponding to a static host. Results are local laboratory measurements, not measurements of a deployed Cloudflare site or the public CDN's latency.

Not independently verified: current regulatory entries, study details, credentials, stock or export conditions in the copy supplied for preservation; exact stock-device dimensions, case foam or accessories; source anatomy segmentation; physical iOS/Android, Safari or Firefox behaviour; production DNS, CDN availability, social previews and email delivery. No email was sent. These limits do not change the supplied device descriptions, status lines or study summaries.
