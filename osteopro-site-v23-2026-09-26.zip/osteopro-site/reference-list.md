# OsteoPro v2 — Step 1 reference list

Research completed 25 September 2026, before design. The approved OsteoPro mockup remains the main visual direction. These are curated or awarded design references; their conversion rates and performance scores were not independently measured. Only design principles were borrowed.

| Reference | Pattern applied |
| --- | --- |
| [WHOOP — Refero](https://styles.refero.design/style/05053a60-1964-4154-9d58-ebdf6352ed3a) | Dark cinematic hero followed by crisp white content; restrained action colour and large headings. |
| [Oura — Refero](https://styles.refero.design/style/9decde51-2a8b-4212-bba5-be9457efc62e) | Tangible close-up hardware, generous space, distinct display and functional typography. |
| [Eight Sleep — Refero](https://styles.refero.design/style/e4e8fe86-47ed-4ddd-a6c6-2c28eae9aabe) | Alternating light/dark sections and a consistent accent for actions. |
| [amp — Refero](https://styles.refero.design/style/261a4ad3-e835-4f7a-beb7-72187f84d462) | Editorial product presentation, equal hardware cards and fine structural borders. |
| [Alveos One — Refero](https://styles.refero.design/style/811f0fc6-3353-4ed6-bf3e-c98b261dcc1c) | Carefully lit hardware and image-led sections paired with concise copy. |
| [Neko Health — 14islands](https://develop.14islands.com/work/neko-health) | Motion directly related to anatomy and measurement, supported by real people. The creator lists Lovie Gold, CSS Design Awards SOTD and FWA SOTD. |
| [Roswell Biotechnologies — FIFTYSEVEN](https://dribbble.com/shots/23891179-Roswell-Biotechnologies-mobile-layout) | Scientific visual storytelling with deliberate small-screen composition. |

[Roswell desktop case study](https://dribbble.com/shots/23619867-The-Roswell-Biotechnologies-Home-page).

## Gallery access record

- Savee: public landing page at savee.com reached; deeper curation required sign-in.
- Refero: public Styles pages supplied the five hardware/health-tech examples above.
- Godly: redirected to recent.design, which could not be retrieved.
- Land-book: public gallery and relevant search results reviewed.
- Awwwards: indexed award listings identified Neko and Roswell; creator case studies were checked. Some direct award pages timed out.
- Mobbin: public catalogue reviewed; deeper examples required sign-in.
- 21st.dev: public component catalogue reviewed for interaction principles. Framework components were not imported into this static site.

## Input status

The missing transparent logo, mobee reference, current-site ZIP and live-demonstration image were subsequently supplied. The build uses `osteopro-site-current.zip`, the v2 brief and the owner's real-assets archive. The older site ZIP is not the source for preserved copy. The seven research selections above have been retained throughout the revision.
