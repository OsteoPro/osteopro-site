# OsteoPro v2 — final Step 2 scorecard

26 September 2026. Self-assessment against the brief, not an independent award judging result. The final sequence followed the requested build checkpoint, combined check, one improvement pass and packaging. Earlier development findings were addressed before this sequence.

| Criterion | Final score / 10 | Evidence |
| --- | ---: | --- |
| 1. First impression | 9 | White OsteoPro header, royal-blue hero, strong two-line headline and equally prominent devices. |
| 2. Hero | 9 | Real C1–sacrum anatomy and back muscles, descending scan, angle scale, two glossy renders, joint arc and pause control. Desktop 3D starts automatically; mobile uses an animated poster scan until “Rotate anatomy” is tapped. |
| 3. Sections below the hero | 9 | Matched clearance cards, genuine software in laptop frames, truthful event photographs, remote-support photography, open-case renders and visually structured study summaries. |
| 4. Layout and typography | 9 | Consistent spacing, restrained type scale, dark/light section rhythm, clear hierarchy and image-led composition based on the seven Step 1 references. |
| 5. Mobile at 375px | 9 | Both products remain prominent; readable single-column sections, working menu, gallery controls and on-demand 3D. Also checked 320px, tablet and wide desktop layouts. |
| 6. Performance and accessibility | 10 | Mobile Lighthouse: home 99/100, each other page 100/100 for performance/accessibility. All pages exceed the requested thresholds. |
| 7. Required copy | 10 | Exact required home strings, product descriptions, feature text, device notes, ARTG lines and three study paragraphs checked against the brief and current-site archive. British English retained. |
| 8. HARD RULES | 10 | Every delivered file searched; no restricted-term matches. Email-only contact, unchanged supplied logo, genuine software, render labels/disclaimers and required anatomy attribution confirmed. |

All eight lines reach the requested pass mark. Visual scores are subjective and take the supplied source-image limitations into account.

## Mobile Lighthouse results

| Page | Performance | Accessibility | FCP | LCP | Blocking time | Layout shift |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Home | 99 | 100 | 0.9 s | 2.0 s | 0 ms | 0 |
| Idiag M360 | 100 | 100 | 0.9 s | 1.4 s | 0 ms | 0 |
| mobee med | 100 | 100 | 0.9 s | 1.4 s | 0 ms | 0 |
| Evidence | 100 | 100 | 0.9 s | 0.9 s | 0 ms | 0 |

Method: Lighthouse mobile preset and default simulated throttling, Chromium 153, locally served static site with HTTP compression. Identical pinned CDN dependencies were mirrored locally because outbound CDN access was restricted. These are laboratory measurements; public CDN latency and deployed Cloudflare performance were not measured. No Lighthouse audit errors or run warnings were returned.

## Combined check and improvement

- All four pages checked at 320, 375, 768, 1440 and 1920 CSS pixels. The sole 320px evidence overflow was corrected in the improvement pass.
- Final targeted axe checks at 320, 375 and 1440 pixels: zero WCAG 2 A/AA and 2.1 AA violations on all four pages. Removing text-opacity fades resolved transient contrast failures.
- Screenshots reviewed at 375 and 1440 pixels, including real scrolling through image-led sections. All images loaded. The mobile 3D activation was exercised successfully.
- Mobile menu open/close, Escape dismissal, keyboard focus, all seven software-gallery choices, motion pause/resume and off-screen pause passed.
- Initial and changed reduced-motion preferences, slow/data-saving connection fallback, and unavailable-worker fallback passed. Navigation and the poster remained visible without JavaScript.
- Required-copy, local-link, asset, metadata, logo-byte-identity and file-content checks passed. The adapted model is 152,592 bytes, below the brief's approximate 3 MB ceiling.
- The home-page result improved from 71 to 99 after keeping graphics-engine startup behind the mobile “Rotate anatomy” control. Both measurement visuals still animate initially on ordinary mobile connections; the spine uses a lightweight poster scan until selected.

## Remaining limits

The supplied event photographs remain visibly low-resolution; truthful crops and presentation adjustments cannot recover absent detail. Device and case renders are illustrations, not stock photographs. Exact case dimensions, foam and accessories were not supplied for verification. Physical device/browser testing, current regulatory entries, source-study details and live hosting were not independently verified. The README records these limits and the model licence. The site has not been published.
